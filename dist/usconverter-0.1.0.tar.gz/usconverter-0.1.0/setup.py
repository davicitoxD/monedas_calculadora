from setuptools import setup

setup(
    name="usconverter",
    version="0.1.0",
    description="USD Converter",
    author="David Runke",
    author_email="davidrunke@gmail.com",
    packages=["src"],
    install_requires=[],
)
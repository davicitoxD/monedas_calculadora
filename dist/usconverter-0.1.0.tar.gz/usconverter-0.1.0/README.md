# monedas_calculadora
app simple escrita en python que convierte pesos ARS y UYU en dolares con la cotización Real consumida por  API

## Diagrama de Secuencia
![image](https://github.com/davicitoxD/monedas_calculadora/assets/8561970/da5275f3-fcf6-4163-89e0-1ae5fe91adfd)
